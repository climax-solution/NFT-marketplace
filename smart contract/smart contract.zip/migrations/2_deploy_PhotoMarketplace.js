const PhotoMarketplace = artifacts.require("Marketplace");
const PhotoNFT = artifacts.require("NFTD");

const _photoNFT = PhotoNFT.address;
// const _marketplaceOwner = '0xCdE2C94E148227c5b3832E0fA31207326D35ea0e';
// const _whiteUser = '0xebc6B3c6F7724BB214b7CF5994078BB883208a98';
const _marketplaceOwner = '0x0F09aE2ba91449a7B4201721f98f482cAF9737Ee';
const _whiteUser = '0x8bD154D7b5ADbDab1d45D5C59512F2e9EbBcF219';

module.exports = async function(deployer) {
    await deployer.deploy(PhotoMarketplace, "0x6f6069f9e4595b5f4f49f331e0d7b6681c9e6a9e", _marketplaceOwner);
};
