const PhotoNFT = artifacts.require("NFTD");
// const owner = "0xCdE2C94E148227c5b3832E0fA31207326D35ea0e";
const owner = "0x0F09aE2ba91449a7B4201721f98f482cAF9737Ee";

module.exports = async function(deployer) {
    await deployer.deploy(PhotoNFT, owner);
};